# Plugin de KOReader para Lecturameter

Envia el tiempo real de lectura (el del plugin de estadisticas de KOReader) al
servidor de sincronizacion de Lecturameter, para que la app rellene la duracion
de la sesion sin cronometro.

## Instalacion

1. Copia la carpeta `lecturameter.koplugin` a la carpeta `plugins/` de KOReader
   en el e-reader (por ejemplo `koreader/plugins/lecturameter.koplugin`).
2. Reinicia KOReader.
3. Comprueba que ya tienes configurada la sincronizacion de progreso (KOSync)
   con tu usuario del servidor de Lecturameter, con el metodo de identificacion
   de documento **binario** (el de por defecto). El plugin usa ese mismo usuario
   y clave; no pide credenciales nuevas.
4. El plugin de **Estadisticas** de KOReader debe estar activado.

## Uso

- Se envia solo al cerrar un libro y al suspender el e-reader, si hay red. Sin
  red no hace nada y lo reintenta la proxima vez.
- Manual: menu principal > Herramientas > Lecturameter > «Enviar tiempo de
  lectura ahora».
- Solo envia las lecturas posteriores al ultimo envio (el marcador se guarda en
  `settings/lecturameter.lua`). La primera vez envia como maximo los ultimos 30 dias.
- Si KOSync identifica los documentos por nombre de archivo, no envia nada y
  muestra un aviso.

La URL del servidor es la constante `SERVER_URL` al inicio de `main.lua`.

No probado en un KOReader real (ver notas del commit).
