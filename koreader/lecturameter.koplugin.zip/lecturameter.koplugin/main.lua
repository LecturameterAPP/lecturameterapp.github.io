--[[
Lecturameter: envia el tiempo real de lectura (statistics.sqlite3) al servidor
de sincronizacion de Lecturameter (POST /v1/lm/stats). Reutiliza el usuario y la
clave de la sincronizacion de progreso (kosync) ya configurados.
]]

-- URL del servidor: unico sitio donde se define (sin barra final).
local SERVER_URL = "https://lecturameter-sync.appaugur.workers.dev"

local DataStorage = require("datastorage")
local InfoMessage = require("ui/widget/infomessage")
local LuaSettings = require("luasettings")
local NetworkMgr = require("ui/network/manager")
local UIManager = require("ui/uimanager")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local json = require("json")
local logger = require("logger")
local ltn12 = require("ltn12")
local socketutil = require("socketutil")

local MAX_ROWS = 500          -- limite del servidor por llamada
local MAX_CHUNKS = 20         -- tope de llamadas por envio
local RETENTION_S = 30 * 86400
local MIN_DURATION, MAX_DURATION = 1, 3600

local Lecturameter = WidgetContainer:extend{
    name = "lecturameter",
    is_doc_only = false,
}

function Lecturameter:init()
    self.settings = LuaSettings:open(DataStorage:getSettingsDir() .. "/lecturameter.lua")
    self.warned_hash = false
    if self.ui and self.ui.menu then
        self.ui.menu:registerToMainMenu(self)
    end
end

-- ---------------------------------------------------------------- credenciales

-- Lee el ajuste de kosync tal como lo guarda cada version del plugin.
function Lecturameter:getKosyncSettings()
    local s = G_reader_settings and G_reader_settings:readSetting("kosync")
    if type(s) == "table" and s.username and s.userkey then
        return s
    end
    local ok, ls = pcall(function()
        return LuaSettings:open(DataStorage:getSettingsDir() .. "/kosync.lua")
    end)
    if ok and ls then
        local u, k = ls:readSetting("username"), ls:readSetting("userkey")
        if u and k then
            return { username = u, userkey = k, checksum_method = ls:readSetting("checksum_method") }
        end
        -- KOReader 2026.07+ guarda kosync.lua como { settings = { username, userkey, ... } }
        local nested = ls:readSetting("settings")
        if type(nested) == "table" and nested.username and nested.userkey then
            return nested
        end
    end
    return nil
end

-- Devuelve el hash del documento abierto (el mismo que kosync) o nil, motivo.
function Lecturameter:getDocumentHash()
    local ks = self:getKosyncSettings()
    if not ks then
        return nil, "Configura primero la sincronizacion de progreso (KOSync)."
    end
    -- kosync: 0 = binario (md5 parcial, por defecto); 1 = nombre de archivo
    if ks.checksum_method ~= nil and ks.checksum_method ~= 0 then
        return nil, "KOSync usa el nombre de archivo como identificador. Cambia el metodo a binario para enviar el tiempo de lectura."
    end
    local doc = self.ui and self.ui.document
    if not doc then
        return nil, "No hay ningun documento abierto."
    end
    local ok, hash = pcall(function() return doc:fastDigest(self.ui.doc_settings) end)
    if (not ok or not hash) and self.ui.doc_settings then
        hash = self.ui.doc_settings:readSetting("partial_md5_checksum")
    end
    if not hash or hash == "" then
        return nil, "No se pudo calcular el identificador del documento."
    end
    return hash, nil
end

-- ---------------------------------------------------------------- estadisticas

function Lecturameter:getDeviceId()
    local id = G_reader_settings and G_reader_settings:readSetting("device_id")
    return type(id) == "string" and id or nil
end

-- Lee (solo lectura) hasta MAX_ROWS filas con start_time > since.
-- Devuelve filas validas, el mayor start_time leido (incluye filas descartadas)
-- y cuantas filas se leyeron en bruto. nil, motivo si falla.
function Lecturameter:readRows(hash, since)
    local path = DataStorage:getSettingsDir() .. "/statistics.sqlite3"
    local ok_mod, SQ3 = pcall(require, "lua-ljsqlite3/init")
    if not ok_mod then
        return nil, "No se encontro el modulo SQLite de KOReader."
    end
    local ok, a, b, c = pcall(function()
        local conn = SQ3.open(path, "ro")
        local stmt = conn:prepare([[
            SELECT p.start_time, p.duration, p.page, p.total_pages
            FROM page_stat_data p JOIN book b ON b.id = p.id_book
            WHERE b.md5 = ? AND p.start_time > ?
            ORDER BY p.start_time ASC LIMIT ?]])
        stmt:reset():bind(hash, since, MAX_ROWS)
        local rows, maxts, raw = {}, since, 0
        local now = os.time()
        while true do
            local r = stmt:step()
            if not r then break end
            raw = raw + 1
            local st, du, pg, tp = tonumber(r[1]), tonumber(r[2]), tonumber(r[3]), tonumber(r[4])
            if st and st > maxts then maxts = st end
            -- el servidor rechaza el lote entero si una fila no es valida: filtrar aqui
            if st and du and pg and tp
                and du >= MIN_DURATION and du <= MAX_DURATION
                and pg >= 0 and tp >= 0
                and st > 1000000000 and st <= now + 86400 then
                rows[#rows + 1] = { start_ts = math.floor(st), duration_s = math.floor(du),
                                    page = math.floor(pg), total_pages = math.floor(tp) }
            end
        end
        stmt:close()
        conn:close()
        return rows, maxts, raw
    end)
    if not ok then
        logger.warn("lecturameter: error leyendo statistics.sqlite3", a)
        return nil, "No se pudo leer las estadisticas de KOReader."
    end
    return a, b, c
end

-- ---------------------------------------------------------------- red

-- Devuelve codigo HTTP (number) o nil, error.
function Lecturameter:post(ks, body)
    local scheme = SERVER_URL:match("^(%a+):")
    local request = (scheme == "https") and require("ssl.https").request or require("socket.http").request
    local resp = {}
    socketutil:set_timeout(10, 30)
    local ok, code = pcall(function()
        local _, c = request{
            url = SERVER_URL .. "/v1/lm/stats",
            method = "POST",
            headers = {
                ["Content-Type"] = "application/json",
                ["Content-Length"] = tostring(#body),
                ["x-auth-user"] = ks.username,
                ["x-auth-key"] = ks.userkey,
            },
            source = ltn12.source.string(body),
            sink = ltn12.sink.table(resp),
        }
        return c
    end)
    socketutil:reset_timeout()
    if not ok then return nil, tostring(code) end
    return tonumber(code), table.concat(resp)
end

-- ---------------------------------------------------------------- envio

-- manual=true muestra mensajes; en automatico solo se registra en el log.
-- pre = {hash=, why=} ya calculado (cierre/suspension: el documento puede no existir al ejecutar).
function Lecturameter:sendNow(manual, pre)
    local function say(msg)
        if manual then
            UIManager:show(InfoMessage:new{ text = msg })
        else
            logger.info("lecturameter:", msg)
        end
    end

    local hash, why
    if pre then hash, why = pre.hash, pre.why else hash, why = self:getDocumentHash() end
    if not hash then
        -- aviso del hash: siempre en manual; una sola vez por sesion en automatico
        if manual or (not self.warned_hash and why and why:find("nombre de archivo", 1, true)) then
            self.warned_hash = true
            UIManager:show(InfoMessage:new{ text = "Lecturameter: " .. why })
        else
            logger.info("lecturameter:", why)
        end
        return
    end
    if not NetworkMgr:isOnline() then
        say("Sin conexion: se reintentara la proxima vez.")
        return
    end
    local ks = self:getKosyncSettings()
    local markers = self.settings:readSetting("last_start") or {}
    local marker = markers[hash] or (os.time() - RETENTION_S)
    local device_id = self:getDeviceId()
    local sent = 0

    for _ = 1, MAX_CHUNKS do
        local rows, maxts, raw = self:readRows(hash, marker)
        if not rows then say(maxts); return end
        if #rows > 0 then
            local body = json.encode{ document = hash, device_id = device_id, rows = rows }
            local code, resp = self:post(ks, body)
            if code == 401 then
                say("El servidor no reconoce el usuario o la clave de KOSync.")
                return
            elseif code ~= 200 then
                logger.warn("lecturameter: envio fallido", code, resp)
                say("No se pudo enviar el tiempo de lectura. Se reintentara.")
                return
            end
            sent = sent + #rows
        end
        -- el marcador solo avanza tras exito (o si no habia nada valido que enviar)
        local advanced = maxts > marker
        marker = maxts
        markers[hash] = marker
        self.settings:saveSetting("last_start", markers)
        self.settings:flush()
        if raw < MAX_ROWS or not advanced then break end
    end
    say(sent > 0 and (sent == 1 and "Enviada 1 lectura a Lecturameter."
            or ("Enviadas " .. sent .. " lecturas a Lecturameter."))
        or "No hay lecturas nuevas que enviar.")
end

-- ---------------------------------------------------------------- eventos y menu

-- ReaderStatistics guarda la sesion en statistics.sqlite3 en su propio
-- onCloseDocument/onSuspend, y puede ejecutarse DESPUES que el nuestro. Por eso
-- calculamos el hash ahora (el documento aun existe) y diferimos el envio al
-- siguiente ciclo del bucle de eventos, cuando el broadcast ya termino y la base
-- esta al dia. No se llama a insertDB: seria doble guardado en statistics.
function Lecturameter:sendDeferred(tag)
    local hash, why = self:getDocumentHash()
    local function run()
        self.pending_send = false
        local ok, err = pcall(self.sendNow, self, false, { hash = hash, why = why })
        if not ok then logger.warn("lecturameter: " .. tag, err) end
    end
    if self.pending_send then return end -- ya hay un envio en cola
    self.pending_send = true
    if UIManager.nextTick then
        UIManager:nextTick(run)
    else
        UIManager:scheduleIn(0.1, run)
    end
end

function Lecturameter:onCloseDocument()
    local ok, err = pcall(self.sendDeferred, self, "onCloseDocument")
    if not ok then self.pending_send = false; logger.warn("lecturameter: onCloseDocument", err) end
end

function Lecturameter:onSuspend()
    if not (self.ui and self.ui.document) then return end
    local ok, err = pcall(self.sendDeferred, self, "onSuspend")
    if not ok then self.pending_send = false; logger.warn("lecturameter: onSuspend", err) end
end

function Lecturameter:addToMainMenu(menu_items)
    menu_items.lecturameter = {
        text = "Lecturameter",
        sorting_hint = "tools",
        sub_item_table = {
            {
                text = "Enviar tiempo de lectura ahora",
                keep_menu_open = false,
                callback = function()
                    self:sendNow(true)
                end,
            },
        },
    }
end

return Lecturameter
