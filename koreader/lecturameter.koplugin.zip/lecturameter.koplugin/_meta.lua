local _ = require("gettext")
return {
    name = "lecturameter",
    fullname = _("Lecturameter"),
    description = _([[Envia a tu servidor de sincronizacion de Lecturameter el tiempo real de lectura (de las estadisticas de KOReader).]]),
}
